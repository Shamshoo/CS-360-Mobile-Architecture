package com.example.inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

/** Login screen. Checks credentials against the users table, or creates a new account. */
public class MainActivity extends AppCompatActivity {

    private EditText usernameText;
    private EditText passwordText;
    private DatabaseHelper database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.ime());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });

        database = DatabaseHelper.getInstance(this);

        usernameText = findViewById(R.id.usernameText);
        passwordText = findViewById(R.id.passwordText);
        Button buttonLogin = findViewById(R.id.buttonLogin);
        Button buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        buttonLogin.setOnClickListener(v -> logIn());
        buttonCreateAccount.setOnClickListener(v -> createAccount());

        // Pressing Done on the keyboard in the password field logs in
        passwordText.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                logIn();
                return true;
            }
            return false;
        });
    }

    /** Checks the username and password against the database. */
    private void logIn() {
        if (!fieldsAreFilled()) {
            return;
        }
        String username = usernameText.getText().toString().trim();
        String password = passwordText.getText().toString();

        if (database.checkUser(username, password)) {
            openNextScreen();
        } else {
            passwordText.setError(getString(R.string.error_login_failed));
        }
    }

    /** Saves a new username and password if the username is not already taken. */
    private void createAccount() {
        if (!fieldsAreFilled()) {
            return;
        }
        String username = usernameText.getText().toString().trim();
        String password = passwordText.getText().toString();

        if (database.userExists(username)) {
            usernameText.setError(getString(R.string.error_username_taken));
        } else if (database.addUser(username, password)) {
            Toast.makeText(this, R.string.account_created, Toast.LENGTH_SHORT).show();
            openNextScreen();
        } else {
            Toast.makeText(this, R.string.error_account_failed, Toast.LENGTH_SHORT).show();
        }
    }

    /** Shows an error on any empty field. Returns true only if both fields have text. */
    private boolean fieldsAreFilled() {
        boolean filled = true;
        if (usernameText.getText().toString().trim().isEmpty()) {
            usernameText.setError(getString(R.string.error_username_required));
            filled = false;
        }
        if (passwordText.getText().toString().isEmpty()) {
            passwordText.setError(getString(R.string.error_password_required));
            filled = false;
        }
        return filled;
    }

    /** The first login goes to the SMS permission screen once; after that, straight to the grid. */
    private void openNextScreen() {
        boolean promptShown = SmsNotifier.prefs(this).getBoolean(SmsNotifier.KEY_PROMPT_SHOWN, false);
        Intent intent;
        if (promptShown) {
            intent = new Intent(this, InventoryActivity.class);
        } else {
            intent = new Intent(this, SmsPermissionActivity.class);
            intent.putExtra(SmsPermissionActivity.EXTRA_FROM_LOGIN, true);
        }
        startActivity(intent);
        finish();
    }
}
