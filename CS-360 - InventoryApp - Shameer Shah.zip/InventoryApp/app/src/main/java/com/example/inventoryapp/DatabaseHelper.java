package com.example.inventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

/**
 * Creates and manages the app's SQLite database.
 * Holds two tables: one for user logins and one for inventory items.
 * Activities call these methods instead of writing SQL themselves.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "inventory.db";
    private static final int DATABASE_VERSION = 1;

    // Users table
    private static final String TABLE_USERS = "users";
    private static final String COL_USER_ID = "_id";
    private static final String COL_USERNAME = "username";
    private static final String COL_PASSWORD_HASH = "password_hash";

    // Items table
    private static final String TABLE_ITEMS = "items";
    private static final String COL_ITEM_ID = "_id";
    private static final String COL_ITEM_NAME = "name";
    private static final String COL_ITEM_QUANTITY = "quantity";

    // One shared instance so every screen uses the same database connection
    private static DatabaseHelper instance;

    public static synchronized DatabaseHelper getInstance(Context context) {
        if (instance == null) {
            instance = new DatabaseHelper(context.getApplicationContext());
        }
        return instance;
    }

    private DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_USERS + " ("
                + COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_USERNAME + " TEXT NOT NULL UNIQUE, "
                + COL_PASSWORD_HASH + " TEXT NOT NULL)");

        db.execSQL("CREATE TABLE " + TABLE_ITEMS + " ("
                + COL_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_ITEM_NAME + " TEXT NOT NULL, "
                + COL_ITEM_QUANTITY + " INTEGER NOT NULL DEFAULT 0)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // No released versions yet, so rebuilding the tables is safe
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ITEMS);
        onCreate(db);
    }

    // ---------- Users ----------

    /** Returns true if an account with this username already exists. */
    public boolean userExists(String username) {
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor cursor = db.query(TABLE_USERS, new String[] { COL_USER_ID },
                COL_USERNAME + " = ?", new String[] { username }, null, null, null)) {
            return cursor.moveToFirst();
        }
    }

    /** Saves a new account. Returns false if the insert failed (for example, a duplicate username). */
    public boolean addUser(String username, String password) {
        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username);
        values.put(COL_PASSWORD_HASH, hashPassword(password));
        return getWritableDatabase().insert(TABLE_USERS, null, values) != -1;
    }

    /** Returns true if the username exists and the password matches. */
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor cursor = db.query(TABLE_USERS, new String[] { COL_USER_ID },
                COL_USERNAME + " = ? AND " + COL_PASSWORD_HASH + " = ?",
                new String[] { username, hashPassword(password) }, null, null, null)) {
            return cursor.moveToFirst();
        }
    }

    /** Stores a SHA-256 hash instead of the plain password so it is not readable in the database file. */
    private static String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(password.getBytes(StandardCharsets.UTF_8));
            StringBuilder hex = new StringBuilder();
            for (byte b : hash) {
                hex.append(String.format("%02x", b));
            }
            return hex.toString();
        } catch (NoSuchAlgorithmException e) {
            // SHA-256 is built into every Android version, so this should never happen
            throw new IllegalStateException("SHA-256 not available", e);
        }
    }

    // ---------- Items ----------

    /** Create: adds a new item and returns its id, or -1 if it failed. */
    public long addItem(String name, int quantity) {
        ContentValues values = new ContentValues();
        values.put(COL_ITEM_NAME, name);
        values.put(COL_ITEM_QUANTITY, quantity);
        return getWritableDatabase().insert(TABLE_ITEMS, null, values);
    }

    /** Read: returns every item, sorted by name, for the inventory grid. */
    public List<InventoryItem> getAllItems() {
        List<InventoryItem> items = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor cursor = db.query(TABLE_ITEMS, null, null, null, null, null,
                COL_ITEM_NAME + " COLLATE NOCASE")) {
            while (cursor.moveToNext()) {
                long id = cursor.getLong(cursor.getColumnIndexOrThrow(COL_ITEM_ID));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(COL_ITEM_NAME));
                int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ITEM_QUANTITY));
                items.add(new InventoryItem(id, name, quantity));
            }
        }
        return items;
    }

    /** Update: changes the quantity of one item. */
    public boolean updateQuantity(long itemId, int quantity) {
        ContentValues values = new ContentValues();
        values.put(COL_ITEM_QUANTITY, quantity);
        int rows = getWritableDatabase().update(TABLE_ITEMS, values,
                COL_ITEM_ID + " = ?", new String[] { String.valueOf(itemId) });
        return rows > 0;
    }

    /** Delete: removes one item. */
    public boolean deleteItem(long itemId) {
        int rows = getWritableDatabase().delete(TABLE_ITEMS,
                COL_ITEM_ID + " = ?", new String[] { String.valueOf(itemId) });
        return rows > 0;
    }

    /** Puts a deleted item back with its original id (used by the Undo button). */
    public void restoreItem(InventoryItem item) {
        ContentValues values = new ContentValues();
        values.put(COL_ITEM_ID, item.getId());
        values.put(COL_ITEM_NAME, item.getName());
        values.put(COL_ITEM_QUANTITY, item.getQuantity());
        getWritableDatabase().insert(TABLE_ITEMS, null, values);
    }
}
