package com.example.inventoryapp;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;

import androidx.core.content.ContextCompat;

/** Sends the zero-stock SMS alert, but only when the user has granted permission. */
public final class SmsNotifier {

    static final String PREFS = "inventory_prefs";
    static final String KEY_PHONE = "sms_phone";
    static final String KEY_PROMPT_SHOWN = "sms_prompt_shown";
    static final String KEY_PERMISSION_ASKED = "sms_permission_asked";

    private SmsNotifier() {
    }

    static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    /** Checks the SEND_SMS permission before any message is sent. */
    public static boolean hasPermission(Context context) {
        return ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    /**
     * Sends "item is out of stock" to the saved phone number.
     * Returns false without sending if permission was denied or no number is saved,
     * so the rest of the app keeps working normally.
     */
    public static boolean sendZeroStockAlert(Context context, String itemName) {
        if (!hasPermission(context)) {
            return false;
        }
        String phone = prefs(context).getString(KEY_PHONE, "");
        if (phone == null || phone.trim().isEmpty()) {
            return false;
        }
        try {
            SmsManager smsManager = context.getSystemService(SmsManager.class);
            if (smsManager == null) {
                return false;
            }
            String message = context.getString(R.string.sms_zero_stock_message, itemName);
            smsManager.sendTextMessage(phone.trim(), null, message, null, null);
            return true;
        } catch (Exception e) {
            // Devices without SMS support, or an invalid number, should not crash the app
            return false;
        }
    }
}
