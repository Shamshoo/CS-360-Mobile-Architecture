package com.example.inventoryapp;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

/** Form for adding an item. Saves it to the database, then returns to the grid. */
public class AddItemActivity extends AppCompatActivity {

    private EditText itemNameText;
    private EditText itemQuantityText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_item);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.ime());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });

        // App bar with a back arrow
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        setTitle(R.string.add_item_title);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        itemNameText = findViewById(R.id.itemNameText);
        itemQuantityText = findViewById(R.id.itemQuantityText);
        Button buttonSave = findViewById(R.id.buttonSave);
        Button buttonCancel = findViewById(R.id.buttonCancel);

        buttonSave.setOnClickListener(v -> save());
        buttonCancel.setOnClickListener(v -> cancel());
        itemQuantityText.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                save();
                return true;
            }
            return false;
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        // Back arrow in the app bar
        if (item.getItemId() == android.R.id.home) {
            cancel();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    /** Create: checks the fields, then adds the item to the database. */
    private void save() {
        String name = itemNameText.getText().toString().trim();
        String quantityText = itemQuantityText.getText().toString().trim();
        boolean valid = true;

        if (name.isEmpty()) {
            itemNameText.setError(getString(R.string.error_item_name_required));
            valid = false;
        }
        int quantity = -1;
        try {
            quantity = Integer.parseInt(quantityText);
        } catch (NumberFormatException e) {
            // Left at -1 so the check below shows an error
        }
        if (quantity < 0) {
            itemQuantityText.setError(getString(R.string.error_quantity_invalid));
            valid = false;
        }
        if (!valid) {
            return;
        }

        long newId = DatabaseHelper.getInstance(this).addItem(name, quantity);
        if (newId == -1) {
            Toast.makeText(this, R.string.error_item_save_failed, Toast.LENGTH_SHORT).show();
            return;
        }
        setResult(RESULT_OK);
        finish();
    }

    private void cancel() {
        setResult(RESULT_CANCELED);
        finish();
    }
}
