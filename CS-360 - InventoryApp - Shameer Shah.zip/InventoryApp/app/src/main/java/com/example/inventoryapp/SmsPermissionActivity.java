package com.example.inventoryapp;

import android.Manifest;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

/**
 * Explains SMS alerts, checks the SEND_SMS permission, asks for it if needed,
 * and shows the user's answer. Denying keeps the app working without alerts.
 */
public class SmsPermissionActivity extends AppCompatActivity {

    public static final String EXTRA_FROM_LOGIN = "extra_from_login";
    private static final int REQUEST_SEND_SMS_CODE = 0;

    private TextView textPermissionStatus;
    private EditText phoneText;
    private Button buttonAllowSms;
    private boolean fromLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_sms_permission);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.ime());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        setTitle(R.string.sms_alerts_title);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        fromLogin = getIntent().getBooleanExtra(EXTRA_FROM_LOGIN, false);
        // This screen opens automatically only once, after the first login
        SmsNotifier.prefs(this).edit().putBoolean(SmsNotifier.KEY_PROMPT_SHOWN, true).apply();

        textPermissionStatus = findViewById(R.id.textPermissionStatus);
        phoneText = findViewById(R.id.phoneText);
        buttonAllowSms = findViewById(R.id.buttonAllowSms);
        Button buttonNotNow = findViewById(R.id.buttonNotNow);

        phoneText.setText(SmsNotifier.prefs(this).getString(SmsNotifier.KEY_PHONE, ""));

        buttonAllowSms.setOnClickListener(v -> onAllowClicked());
        buttonNotNow.setOnClickListener(v -> continueOrClose());

        updateStatus();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            continueOrClose();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void onAllowClicked() {
        String phone = phoneText.getText().toString().trim();
        if (phone.isEmpty()) {
            phoneText.setError(getString(R.string.error_phone_required));
            return;
        }
        SmsNotifier.prefs(this).edit().putString(SmsNotifier.KEY_PHONE, phone).apply();

        // Check the permission first, and only ask if it has not been granted
        if (SmsNotifier.hasPermission(this)) {
            continueOrClose();
        } else {
            ActivityCompat.requestPermissions(this,
                    new String[] { Manifest.permission.SEND_SMS }, REQUEST_SEND_SMS_CODE);
        }
    }

    // Called after the user taps Allow or Don't allow in the permission dialog
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_SEND_SMS_CODE) {
            SmsNotifier.prefs(this).edit().putBoolean(SmsNotifier.KEY_PERMISSION_ASKED, true).apply();
            updateStatus();
        }
    }

    /** Shows the current permission state so the user knows if alerts are on. */
    private void updateStatus() {
        boolean granted = SmsNotifier.hasPermission(this);
        boolean asked = SmsNotifier.prefs(this).getBoolean(SmsNotifier.KEY_PERMISSION_ASKED, false);

        if (granted) {
            textPermissionStatus.setText(R.string.status_granted);
            textPermissionStatus.setTextColor(ContextCompat.getColor(this, R.color.primary_dark));
            buttonAllowSms.setText(R.string.save_and_continue);
        } else if (asked) {
            textPermissionStatus.setText(R.string.status_denied);
            textPermissionStatus.setTextColor(ContextCompat.getColor(this, R.color.error));
            buttonAllowSms.setText(R.string.allow_sms);
        } else {
            textPermissionStatus.setText(R.string.status_not_requested);
            textPermissionStatus.setTextColor(ContextCompat.getColor(this, R.color.text_primary));
            buttonAllowSms.setText(R.string.allow_sms);
        }
    }

    private void continueOrClose() {
        if (fromLogin) {
            startActivity(new Intent(this, InventoryActivity.class));
        }
        finish();
    }
}
