package com.example.inventoryapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/** Binds inventory items to rows in the grid. */
public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ViewHolder> {

    /** Row actions are passed back to the activity. */
    public interface Listener {
        void onQuantityChange(int position, int delta);

        void onDelete(int position);
    }

    private final List<InventoryItem> items;
    private final Listener listener;

    public InventoryAdapter(List<InventoryItem> items, Listener listener) {
        this.items = items;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_inventory, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        InventoryItem item = items.get(position);
        Context context = holder.itemView.getContext();
        boolean outOfStock = item.getQuantity() == 0;

        holder.textName.setText(item.getName());
        holder.textQuantity.setText(String.valueOf(item.getQuantity()));
        holder.textStatus.setText(outOfStock ? R.string.status_out_of_stock : R.string.status_in_stock);

        // Out-of-stock rows use the error color so they stand out in the grid
        int statusColor = ContextCompat.getColor(context,
                outOfStock ? R.color.error : R.color.text_secondary);
        int quantityColor = ContextCompat.getColor(context,
                outOfStock ? R.color.error : R.color.text_primary);
        holder.textStatus.setTextColor(statusColor);
        holder.textQuantity.setTextColor(quantityColor);

        holder.buttonDecrease.setEnabled(!outOfStock);
        holder.buttonDecrease.setAlpha(outOfStock ? 0.38f : 1f);

        // Spoken labels for screen readers
        holder.buttonDecrease.setContentDescription(context.getString(R.string.cd_decrease, item.getName()));
        holder.buttonIncrease.setContentDescription(context.getString(R.string.cd_increase, item.getName()));
        holder.buttonDelete.setContentDescription(context.getString(R.string.cd_delete, item.getName()));

        holder.buttonDecrease.setOnClickListener(v -> notifyListener(holder, -1));
        holder.buttonIncrease.setOnClickListener(v -> notifyListener(holder, 1));
        holder.buttonDelete.setOnClickListener(v -> {
            int pos = holder.getBindingAdapterPosition();
            if (pos != RecyclerView.NO_POSITION) {
                listener.onDelete(pos);
            }
        });
    }

    private void notifyListener(ViewHolder holder, int delta) {
        int pos = holder.getBindingAdapterPosition();
        if (pos != RecyclerView.NO_POSITION) {
            listener.onQuantityChange(pos, delta);
        }
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        final TextView textName;
        final TextView textStatus;
        final TextView textQuantity;
        final ImageButton buttonDecrease;
        final ImageButton buttonIncrease;
        final ImageButton buttonDelete;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            textName = itemView.findViewById(R.id.textItemName);
            textStatus = itemView.findViewById(R.id.textItemStatus);
            textQuantity = itemView.findViewById(R.id.textItemQuantity);
            buttonDecrease = itemView.findViewById(R.id.buttonDecrease);
            buttonIncrease = itemView.findViewById(R.id.buttonIncrease);
            buttonDelete = itemView.findViewById(R.id.buttonDelete);
        }
    }
}
