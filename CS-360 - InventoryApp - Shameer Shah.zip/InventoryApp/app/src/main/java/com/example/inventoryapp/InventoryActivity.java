package com.example.inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.List;

/** Inventory grid: reads every item from the database and lets the user add, update, and delete them. */
public class InventoryActivity extends AppCompatActivity implements InventoryAdapter.Listener {

    private final List<InventoryItem> items = new ArrayList<>();
    private DatabaseHelper database;
    private InventoryAdapter adapter;
    private TextView textSummary;
    private TextView textEmpty;

    // When AddItemActivity saves a new item, reload the grid from the database
    private final ActivityResultLauncher<Intent> addItemLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == RESULT_OK) {
                    reloadItems();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_inventory);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });

        // Use the layout's Toolbar as this screen's app bar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        setTitle(R.string.inventory_title);

        database = DatabaseHelper.getInstance(this);
        textSummary = findViewById(R.id.textSummary);
        textEmpty = findViewById(R.id.textEmpty);

        RecyclerView recyclerView = findViewById(R.id.recyclerInventory);
        adapter = new InventoryAdapter(items, this);
        recyclerView.setAdapter(adapter);

        FloatingActionButton fabAddItem = findViewById(R.id.fabAddItem);
        fabAddItem.setOnClickListener(v ->
                addItemLauncher.launch(new Intent(this, AddItemActivity.class)));

        reloadItems();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_inventory, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.action_sms_alerts) {
            startActivity(new Intent(this, SmsPermissionActivity.class));
            return true;
        } else if (item.getItemId() == R.id.action_logout) {
            Intent intent = new Intent(this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    /** Read: loads all items from the database into the grid. */
    private void reloadItems() {
        items.clear();
        items.addAll(database.getAllItems());
        adapter.notifyDataSetChanged();
        updateSummary();
    }

    /** Update: called when + or - is tapped on a row. */
    @Override
    public void onQuantityChange(int position, int delta) {
        InventoryItem item = items.get(position);
        int oldQuantity = item.getQuantity();
        int newQuantity = Math.max(0, oldQuantity + delta);
        if (newQuantity == oldQuantity || !database.updateQuantity(item.getId(), newQuantity)) {
            return;
        }

        item.setQuantity(newQuantity);
        adapter.notifyItemChanged(position);
        updateSummary();

        // Item just reached zero: send the SMS alert if the user allowed it
        if (newQuantity == 0) {
            boolean sent = SmsNotifier.sendZeroStockAlert(this, item.getName());
            int message = sent ? R.string.out_of_stock_sms_sent : R.string.out_of_stock_no_sms;
            Snackbar.make(findViewById(R.id.main), getString(message, item.getName()),
                    Snackbar.LENGTH_LONG).show();
        }
    }

    /** Delete: called when the trash button is tapped on a row. */
    @Override
    public void onDelete(int position) {
        InventoryItem removed = items.get(position);
        if (!database.deleteItem(removed.getId())) {
            return;
        }
        items.remove(position);
        adapter.notifyItemRemoved(position);
        updateSummary();

        // Undo puts the item back in the database with its original id
        Snackbar.make(findViewById(R.id.main), getString(R.string.item_deleted, removed.getName()),
                        Snackbar.LENGTH_LONG)
                .setAction(R.string.undo, v -> {
                    database.restoreItem(removed);
                    reloadItems();
                })
                .show();
    }

    /** Updates the item count line and shows the empty message when there are no items. */
    private void updateSummary() {
        int outOfStock = 0;
        for (InventoryItem item : items) {
            if (item.getQuantity() == 0) {
                outOfStock++;
            }
        }
        textSummary.setText(getString(R.string.summary_format, items.size(), outOfStock));
        textEmpty.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
    }
}
